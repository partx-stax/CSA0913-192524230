import java.util.*;
public class TriageDemo{
    record Patient(String name,int severity,long arrival){}
    public static void main(String[] args){
        Comparator<Patient> order=Comparator.comparingInt(Patient::severity)
          .thenComparingLong(Patient::arrival);
        PriorityQueue<Patient> q=new PriorityQueue<>(order);
        String[] names={"A","B","C","D","E","F","G","H"};
        int[] sev={5,1,3,1,2,5,3,2};
        for(int i=0;i<names.length;i++)q.add(new Patient(names[i],sev[i],i));
        while(!q.isEmpty())System.out.println(q.remove());
    }
}
