public class StringBuildDemo{
 public static void main(String[] args){
  StringBuilder b=new StringBuilder();
  for(int i=1;i<=5;i++)b.append("entry-").append(i).append('\n');
  System.out.print(b);
 }
}
