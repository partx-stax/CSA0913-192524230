import java.util.*;
import java.nio.file.*;
public class CollectionBenchmark{
 public static void main(String[] args)throws Exception{
  int[] sizes={1000,10000,100000}; Random r=new Random(42);
  try(var w=Files.newBufferedWriter(Path.of("benchmark.csv"))){
   w.write("size,hash_lookup_ns,tree_lookup_ns\n");
   for(int n:sizes){
    Map<Integer,Integer> h=new HashMap<>(); Map<Integer,Integer> t=new TreeMap<>();
    for(int i=0;i<n;i++){h.put(i,i);t.put(i,i);}
    int[] keys=new int[200000]; for(int i=0;i<keys.length;i++)keys[i]=r.nextInt(n);
    long s=System.nanoTime(); long sum=0; for(int k:keys)sum+=h.get(k); long ht=System.nanoTime()-s;
    s=System.nanoTime(); for(int k:keys)sum+=t.get(k); long tt=System.nanoTime()-s;
    w.write(n+","+ht+","+tt+"\n"); System.out.println(n+" hash="+ht+"ns tree="+tt+"ns checksum="+sum);
   }
  }
 }
}
