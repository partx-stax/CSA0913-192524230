import java.util.*;
public class MapChoiceDemo{
 public static void main(String[] args){
  Map<String,Integer> stock=new HashMap<>(); stock.put("MED-02",8); stock.put("MED-01",12);
  System.out.println("lookup="+stock.get("MED-01"));
  System.out.println("sorted="+new TreeMap<>(stock));
  System.out.println("insertion="+new LinkedHashMap<>(stock));
 }
}
