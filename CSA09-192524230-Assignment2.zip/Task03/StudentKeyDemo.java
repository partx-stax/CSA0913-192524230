import java.util.*;
class StudentKey {
    final String regNo;
    StudentKey(String r){if(r==null||r.isBlank())throw new IllegalArgumentException();regNo=r;}
    public boolean equals(Object o){return o instanceof StudentKey s && regNo.equals(s.regNo);}
    public int hashCode(){return Objects.hash(regNo);}
}
public class StudentKeyDemo{
    public static void main(String[] args){
        Set<StudentKey> set=new HashSet<>();
        set.add(new StudentKey("192524230")); set.add(new StudentKey("192524230"));
        set.add(new StudentKey("192524231"));
        System.out.println("Unique students: "+set.size());
    }
}
