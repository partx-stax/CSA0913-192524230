# Assignment 2 – CO2: Collections, Generics and Ranking

## Student details
Name: Parthiban M | Register No.: 192524230 | Department: AI & DS | Faculty: Dr. K. Pavithra

## Q1 – String, StringBuilder and StringBuffer
`String` is immutable; repeated concatenation in a loop creates intermediate objects and can take O(n²) total copying for n appended fragments. `StringBuilder` is mutable and unsynchronized, so repeated append is amortized O(n) total and is best for a method-local report builder. `StringBuffer` is synchronized; it is appropriate only when the same mutable buffer is genuinely shared between threads. Synchronization adds overhead and does not make a multi-step business operation atomic. For 10,000 log fragments, use one StringBuilder and append each fragment; expected complexity O(total output characters), space O(total output characters).

## Q2 – ArrayList, LinkedList and ArrayDeque
For an indexed read-heavy student list, ArrayList is the best default: get(i) O(1), append amortized O(1), middle insertion/removal O(n). LinkedList has O(1) insertion after a known node but finding an index is O(n), and has one node allocation plus two links per element. ArrayDeque is preferable for queue/stack ends: add/remove at either end amortized O(1), indexed access unavailable. Use ArrayList for course roster display and ArrayDeque for pending jobs.

## Q3 – hashCode–equals contract
If two objects are equal according to equals(), they must return the same hashCode(). Unequal objects may collide. A HashSet first uses the hash to select a bucket and then equals() to distinguish entries. Mutable fields used by equals/hashCode must not change while the object is a key or set member. The code in `Task03/StudentKeyDemo.java` uses immutable register number as identity and demonstrates duplicate suppression.

## Q4 – Pharmacy inventory map choice
HashMap gives expected O(1) lookup/update and does not preserve order. TreeMap gives O(log n) lookup/update and sorted medicine-code traversal. LinkedHashMap gives expected O(1) lookup/update and predictable insertion order. For a pharmacy lookup by medicine code, use HashMap; use TreeMap when the daily report must be sorted by code; use LinkedHashMap for a stable insertion-order audit display. All require O(n) storage.

## Q5 – Generic ranking
A generic `Leaderboard<T>` accepts `Comparator<? super T>`. `ranking()` copies the internal list then sorts the copy, so callers cannot mutate internal order. The comparator sorts points descending, goal difference descending, and name ascending. Sorting is O(n log n), copying is O(n) time and O(n) extra space. A comparator is more reusable than hard-coding Comparable when teams, players and colleges need different ranking policies.

## Q6 – Hospital triage queue
A FIFO queue cannot put critical patients ahead of minor patients. A PriorityQueue ordered by severity ascending and arrival sequence ascending provides O(log n) insertion and O(log n) removal. A sequence number provides FIFO among equal severities. Iterating/printing PriorityQueue does not guarantee sorted order; repeatedly poll a copy to display treatment order. Starvation can be reduced by aging: periodically raise effective priority based on wait time, while preserving a maximum bound.

## Q7 – Diagnose, redesign and validate
A robust ranking/collection design should state invariants, compare original and revised structures under the same generated inputs, and report repeated measurements rather than inventing timings. The supplied `CollectionBenchmark.java` runs repeatable String concatenation and collection lookup comparisons and writes raw CSV data. Run it locally and include the produced CSV and console output. A hash-based lookup is expected O(1) average but uses additional table memory; a tree-based lookup is O(log n) and keeps keys ordered. Select the structure based on the required operation, not on a single timing.

## Complexity summary
| Operation | ArrayList | LinkedList | ArrayDeque |
|---|---:|---:|---:|
| get(index) | O(1) | O(n) | not supported |
| append/end insert | amortized O(1) | O(1) | amortized O(1) |
| remove front | O(n) | O(1) | O(1) |
| search | O(n) | O(n) | O(n) |

## Execution evidence
Run all Java files with Java 17 or later. Paste actual output screenshots and benchmark CSV after running on your own machine. The environment-specific benchmark values must not be represented as universal results.
