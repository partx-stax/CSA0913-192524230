import java.util.*;
public class CollectionChoiceDemo{
 public static void main(String[] args){
  List<String> roster=new ArrayList<>(List.of("Arun","Divya","Kavi"));
  Deque<String> jobs=new ArrayDeque<>(); jobs.addLast("print"); jobs.addLast("email");
  System.out.println(roster.get(1)); System.out.println(jobs.removeFirst());
 }
}
