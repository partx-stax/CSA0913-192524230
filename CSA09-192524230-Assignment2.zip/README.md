# CSA09-192524230-Assignment2
Name: Parthiban M
Register No.: 192524230
Department: AI & DS
Faculty: Dr. K. Pavithra
Java: 17+

Compile/run each program from its folder, e.g. `javac Task05/LeaderboardDemo.java` then `java -cp Task05 LeaderboardDemo`. Benchmark: `javac Task07/CollectionBenchmark.java` then run; it creates benchmark.csv. Add screenshots and actual measurements after local execution. Repository name: CSA09-192524230-Assignment2.
