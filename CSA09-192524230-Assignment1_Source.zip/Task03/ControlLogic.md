# Task 3 – Design the Control Logic

## Pseudocode – allocate
```
ALGORITHM Allocate(vehicleNo)
    IF vehicleNo is null or blank THEN RETURN failure
    FOR each floor f from 0 to floorCount - 1
        FOR each slot s from 0 to slotCount(f) - 1
            IF slots[f][s] is empty THEN
                slots[f][s] <- vehicleNo
                RETURN (f, s)
            END IF
        END FOR
    END FOR
    RETURN no-space
END ALGORITHM
```

## Pseudocode – compute fee
```
ALGORITHM ComputeFee(vehicle, minutes, user, chargingKWh)
    IF minutes < 0 THEN REJECT
    IF user has valid monthly pass AND user is Student or Staff THEN RETURN 0
    hours <- 0
    IF minutes > 0 THEN hours <- (minutes + 59) DIV 60
    fee <- hours * vehicle.ratePerHour
    IF vehicle is chargeable THEN fee <- fee + chargingKWh * chargingRate
    RETURN fee
END ALGORITHM
```
A zero-minute stay produces zero parking hours. The slab policy can be extended with `if/else` for first hour, subsequent hours and a daily cap. `return` stops immediately after allocation; `break` can stop a loop when a match is found; `continue` skips incompatible slots.

## Completed `ParkingFacility` code
See `Task03/ParkingFacility.java`. It searches floor-by-floor and slot-by-slot, returns the first free coordinate, and validates both indexes and occupancy before releasing.

## Complexity
For F floors and at most S slots per floor, linear scan allocation is O(F·S) worst case and O(1) extra space. Release by known coordinates is O(1). Maintaining per-floor free-slot stacks and counts makes allocation/release O(1) amortized, but requires O(F·S) additional stack storage (or equivalent free-index storage) and careful consistency when slots are reserved or removed.
