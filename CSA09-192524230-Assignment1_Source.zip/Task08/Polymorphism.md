# Task 8 – Apply Polymorphism

Compile-time polymorphism is method overloading: `calculateFee(int minutes)` and `calculateFee(LocalDateTime in, LocalDateTime out)` have different parameter lists. The compiler selects the overload from the declared argument types. Runtime polymorphism occurs when a `Vehicle` reference points to a `Car` or `TwoWheeler` object and the overridden `ratePerHour()` is selected at runtime.

Example:
```java
Vehicle[] parked = {
  new TwoWheeler("TN01A1"), new Car("TN02B2"),
  new ElectricCar("TN03C3")
};
```
Trace: declared reference type is `Vehicle`; actual object type is `ElectricCar`; calling `calculateFee(130)` executes the inherited Vehicle method, which dispatches `ratePerHour()` to Car's implementation (Rs.30/hour). The Chargeable interface then contributes Rs.120 for 10 kWh. The result is Rs.210.

This avoids repeated type checks and long if/else chains. Virtual dispatch is effectively O(1) per call; an `instanceof` chain can perform up to k checks. Code size and maintenance increase with central type-checking as new categories are added.
