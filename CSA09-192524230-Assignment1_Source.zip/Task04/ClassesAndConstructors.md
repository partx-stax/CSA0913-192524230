# Task 4 – Design Classes, Objects and Constructors

`Vehicle` contains common state and an abstract rate method; subclasses initialise the common registration number through `super`. `ParkingTicket` contains ticket id, vehicle, slot and entry timestamp. `ParkingSlot` contains floor/slot number and current vehicle. `ParkingFacility` owns a jagged slot structure and ticket counter/service methods.

A default constructor is useful only where a meaningful empty object exists (for example, a facility configured later is not recommended). Parameterised constructors establish required state. Overloaded constructors can accept either a registration and rate configuration or a registration plus default rate. `this(...)` chains constructors to avoid duplicate validation. `super(...)` initialises superclass state. A copy constructor is not needed for issuing tickets: a reissued ticket should preserve the original ticket identity only when explicitly requested; otherwise issue a new unique ticket id.

Example:
```java
class ParkingTicket {
  private final long id;
  private final Vehicle vehicle;
  ParkingTicket(long id, Vehicle vehicle) {
    this.id = id;
    this.vehicle = vehicle;
  }
}
```
A local reference variable is typically held in a stack frame; the created object resides on the heap. Passing an object passes its reference value. Garbage collection becomes possible when no reachable reference points to the object.

## Alternative creation approaches
Setter-based creation (`new ParkingTicket(); setVehicle(...); setEntry(...)`) can temporarily create invalid or incomplete objects and requires repeated validation. Constructor creation validates once and produces a valid immutable ticket. A static factory (`ParkingTicket.create(...)`) can validate, name creation modes and return cached/subclass instances if appropriate. Creating n tickets takes O(n) total time and O(n) heap space in all three approaches; setter/factory/constructor dispatch does not change asymptotic complexity. Constructor invariants make the constructor approach safest.
