# CSA09-192524230-Assignment1
**Student:** Parthiban M  
**Register No.:** 192524230  
**Department:** AI & DS  
**Faculty:** Dr. K. Pavithra  

## Java version
Java 17 or later (the FeeDemo uses pattern matching for instanceof).

## Compile and run
From the repository root:
```bash
javac Task03/ParkingFacility.java && java -cp Task03 ParkingFacility
javac Task08/FeeDemo.java && java -cp Task08 FeeDemo
javac Task11/SmartParkingDemo.java && java -cp Task11 SmartParkingDemo
javac Task12/DesignChallengeDemo.java && java -cp Task12 DesignChallengeDemo
```
Each task folder contains the relevant explanation or source. Run each program and capture terminal screenshots for the report. Replace the report's test-result placeholders with your own observed output. Commit each task separately as required by the assignment.
