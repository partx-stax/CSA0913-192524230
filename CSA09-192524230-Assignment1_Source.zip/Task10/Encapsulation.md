# Task 10 – Enforce Encapsulation through Packages and Access Modifiers

Suggested packages:
- `parking.model`: Vehicle, subclasses, ParkingTicket, ParkingSlot, ParkingUser
- `parking.service`: ParkingFacility, ParkingService, PricingRule
- `parking.app`: Main/demo and input handling

Fields are `private` to protect invariants. Constructors and public service methods expose controlled operations. `protected` is used only for subclass extension points such as `ratePerHour()`. Package-private access is suitable for internal helpers that should not become public API. Getters expose read-only values; setters validate non-negative durations, positive slot numbers and nonblank registration numbers. Immutable identity fields should have no setter.

Wrapper classes such as `Integer` may be used in collections (`ArrayList<Integer>`); autoboxing converts between `int` and `Integer`. Avoid comparing wrapper objects with `==` because it may compare references; use `equals()` or unbox safely. Beware of null unboxing causing `NullPointerException`.

## Alternative: public fields
Public mutable fields allow calling code to assign invalid values and bypass validation. If validation is moved to callers, each update site must repeat the same checks, creating inconsistent behaviour. Validation itself is O(1) per update, but duplicated across m call sites it creates O(m) maintenance locations. Encapsulation centralises the same O(1) check in one setter/constructor.
