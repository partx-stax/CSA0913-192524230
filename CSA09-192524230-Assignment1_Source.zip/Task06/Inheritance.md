# Task 6 – Design the Inheritance Hierarchy

Vehicle is the superclass. TwoWheeler and Car extend Vehicle (hierarchical inheritance); ElectricCar extends Car (multilevel inheritance) and implements Chargeable. Student, Staff and Visitor can extend an abstract ParkingUser or implement a PassHolder capability. Vehicle owns registration number and common fee interface; each subclass supplies its hourly rate; ElectricCar adds charging behaviour.

## UML class diagram
```
                 <<abstract>> Vehicle
                 - regNo: String
                 + calculateFee(minutes): double
                 + ratePerHour(): double {abstract}
                    /                 \
             TwoWheeler                Car
             rate = 10                  rate = 30
                                         |
                                     ElectricCar ----|> Chargeable
                                     chargingFee(kWh)

ParkingUser (abstract)
      /             |              \
  Student          Staff           Visitor
 monthlyPass     monthlyPass       oneDayPass (new rule)
```

Constructor trace for `new ElectricCar("TN03C3")`:
1. ElectricCar constructor starts and invokes `super(regNo)`.
2. Car constructor starts and invokes `super(regNo)`.
3. Vehicle constructor stores the registration number.
4. Car constructor completes.
5. ElectricCar constructor completes.

`super` invokes a parent constructor and can call an overridden parent implementation where appropriate. The design uses is-a inheritance for genuine specialisation; capabilities such as charging are interfaces because not every vehicle is chargeable.

## Alternative: composition
A single Vehicle could hold a `VehicleType`/`PricingPolicy` object. Adding a type then means adding a policy rather than a subclass; this is more flexible for runtime configuration and orthogonal capabilities. Fee calculation remains O(1) for either approach. Inheritance stores the subclass-specific state plus object overhead; composition adds one policy reference (and policy object if not shared) per vehicle. Composition is preferable when categories and pricing rules change independently.
