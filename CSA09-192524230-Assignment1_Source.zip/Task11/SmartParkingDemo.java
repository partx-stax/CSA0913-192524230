import java.time.*;
import java.util.*;

abstract class ParkedVehicle {
    private final String regNo;
    ParkedVehicle(String regNo) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Registration required");
        this.regNo = regNo;
    }
    public String getRegNo() { return regNo; }
    abstract double hourlyRate();
    double parkingFee(long minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Negative duration");
        return ((minutes + 59) / 60) * hourlyRate();
    }
}
class Bike extends ParkedVehicle {
    Bike(String r) { super(r); }
    double hourlyRate() { return 10; }
}
class Sedan extends ParkedVehicle {
    Sedan(String r) { super(r); }
    double hourlyRate() { return 30; }
}
class EV extends Sedan {
    EV(String r) { super(r); }
    double totalFee(long minutes, double kWh) { return parkingFee(minutes) + kWh * 12; }
}
class Ticket {
    private static long nextId = 1000;
    final long id = nextId++;
    final ParkedVehicle vehicle;
    final int floor, slot;
    final LocalDateTime entry;
    Ticket(ParkedVehicle v, int f, int s, LocalDateTime t) {
        vehicle = v; floor = f; slot = s; entry = t;
    }
}
class SmartFacility {
    private final ParkedVehicle[][] slots;
    private final Map<String, Ticket> active = new HashMap<>();
    SmartFacility(int[] capacities) {
        slots = new ParkedVehicle[capacities.length][];
        for (int i=0; i<capacities.length; i++) slots[i] = new ParkedVehicle[capacities[i]];
    }
    Ticket enter(ParkedVehicle v) {
        if (active.containsKey(v.getRegNo())) throw new IllegalArgumentException("Duplicate active registration");
        for (int f=0; f<slots.length; f++) {
            for (int s=0; s<slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = v;
                    Ticket t = new Ticket(v, f, s, LocalDateTime.now());
                    active.put(v.getRegNo(), t);
                    return t;
                }
            }
        }
        throw new IllegalStateException("Parking full");
    }
    double exit(String regNo, long minutes, double kWh) {
        Ticket t = active.remove(regNo);
        if (t == null) throw new IllegalArgumentException("No active ticket");
        slots[t.floor][t.slot] = null;
        if (t.vehicle instanceof EV ev) return ev.totalFee(minutes, kWh);
        return t.vehicle.parkingFee(minutes);
    }
}
public class SmartParkingDemo {
    public static void main(String[] args) {
        SmartFacility p = new SmartFacility(new int[]{2, 1});
        p.enter(new Bike("TN01A1"));
        p.enter(new Sedan("TN02B2"));
        p.enter(new EV("TN03C3"));
        System.out.println("Bike fee Rs " + p.exit("TN01A1", 61, 0));
        System.out.println("Car fee Rs " + p.exit("TN02B2", 130, 0));
        System.out.println("EV fee Rs " + p.exit("TN03C3", 130, 10));
        System.out.println("Expected daily total Rs 320.0");
    }
}