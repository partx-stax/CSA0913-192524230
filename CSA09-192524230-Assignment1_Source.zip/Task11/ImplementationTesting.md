# Task 11 – Implement, Test and Defend the Design

The executable demonstration is in `Task11/SmartParkingDemo.java`. It uses an abstract Vehicle, specialised vehicle classes, a Chargeable interface, a jagged floor/slot structure, a unique ticket counter and a registration-keyed active-ticket map.

## Test plan and results
The test table below describes deterministic unit/demo cases. Run the supplied Java programs locally and replace/confirm actual-result entries with your console output before submission.

| Case | Input / condition | Expected result |
|---|---|---|
| Normal two-wheeler | 61 minutes, Rs.10/hour | Rs.20 |
| Normal car | 130 minutes, Rs.30/hour | Rs.90 |
| EV + charging | 130 minutes + 10 kWh | Rs.210 |
| Zero duration | 0 minutes | Rs.0 |
| Slab boundary | 60 minutes, car | Rs.30 |
| Last free slot | allocate into final empty slot | allocation succeeds |
| Full facility | allocate when all slots occupied | no slot / null |
| Duplicate registration | second active entry with same regNo | rejected |
| Invalid slot | negative/out-of-range coordinate | release returns false |
| Monthly pass | valid student/staff pass | Rs.0 |

## Hand calculation
Example daily collection: one two-wheeler parks 61 minutes (2 × Rs.10 = Rs.20), one car parks 130 minutes (3 × Rs.30 = Rs.90), and one EV parks 130 minutes with 10 kWh charging (3 × Rs.30 + 10 × Rs.12 = Rs.210). Total = Rs.20 + Rs.90 + Rs.210 = **Rs.320**. Valid monthly-pass users add Rs.0.

## Evaluation
Encapsulation protects identity and occupancy; inheritance models vehicle specialisation; polymorphism chooses rates; abstraction separates the common fee workflow and chargeable capability. A limitation is that the basic hourly-rate model does not yet model peak/off-peak windows or complex calendar-based pricing; Task 12 addresses this by introducing PricingRule objects.

## Alternative ticket storage
An array requires O(n) search by registration number unless an index is maintained. ArrayList has O(n) lookup and O(1) amortized append; HashMap<String, ParkingTicket> offers expected O(1) lookup/insert and O(n) space for n active tickets. HashMap is selected for exit processing by registration number.
