# Task 7 – Override and Specialise Behaviour

Each subclass overrides `ratePerHour()`; the inherited `calculateFee()` calls it dynamically. `@Override` lets the compiler verify that the method signature truly overrides a superclass method. The method must have the same signature, a compatible covariant return type, and cannot reduce visibility. Static methods are hidden, not overridden.

`final` is appropriate for registration number and ticket number because identity should not change; a final method can protect a critical invariant, while a final class prevents subclassing when extension is unsafe.

`equals()` and `hashCode()` should use the same identity field. The supplied code compares registration numbers, so two Vehicle instances with the same registration compare equal and have the same hash code. This is correct if registration number is globally unique across active vehicles. If registration numbers can be reused across separate campuses, equality should include a campus/facility identifier.

## Alternative: switch on type
A single `calculateFee()` can switch on a type enum and choose a rate. Each calculation is O(1) for a switch over a fixed enum (or O(k) for a chain of k tests). But adding a category requires editing the central method and often its tests, increasing coupling. Overriding keeps the common algorithm stable and adds behaviour in a new subtype.
