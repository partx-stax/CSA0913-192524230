# Task 5 – Apply Static Members and the Object Life Cycle

A static `nextTicketNumber` belongs to the ParkingTicket class because all tickets must draw from one sequence; an instance counter would restart for each facility and could duplicate ticket numbers. A static method can expose a safe ticket factory or validate a registration format without needing an object. A static block is suitable only for one-time immutable configuration, not mutable runtime occupancy.

When a vehicle exits, the active-ticket map removes the ticket and the slot releases its vehicle. The ticket/vehicle objects become eligible for garbage collection only when no other reachable reference remains (for example, no history list retains them). Methods receive object references and can return ticket or slot objects; Java passes reference values by value.

## Alternative: counter per facility
If each of k ParkingFacility objects owns an instance counter, each facility can issue ticket 1, so north and south facilities may collide unless ticket ids include a facility prefix. A static global counter uses O(1) counter storage regardless of k and n tickets. Per-facility counters use O(k) counter storage. A robust distributed design can use a facility identifier plus a local sequence or UUID.
