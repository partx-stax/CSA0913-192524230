import java.time.LocalTime;

interface PricingRule { double fee(long minutes, LocalTime entry); }
class HourlyRule implements PricingRule {
    private final double rate;
    HourlyRule(double rate) { this.rate = rate; }
    public double fee(long minutes, LocalTime entry) {
        if (minutes < 0) throw new IllegalArgumentException("Negative duration");
        return ((minutes + 59) / 60) * rate;
    }
}
class FlatRule implements PricingRule {
    private final double amount;
    FlatRule(double amount) { this.amount = amount; }
    public double fee(long minutes, LocalTime entry) { return amount; }
}
class DeliveryVanRule implements PricingRule {
    private final double carRate;
    DeliveryVanRule(double carRate) { this.carRate = carRate; }
    public double fee(long minutes, LocalTime entry) {
        double multiplier = (!entry.isBefore(LocalTime.of(9,0)) &&
                             entry.isBefore(LocalTime.of(17,0))) ? 2.0 : 1.0;
        return ((minutes + 59) / 60) * carRate * multiplier;
    }
}
class OneDayPass {
    private final java.time.LocalDate validDate;
    OneDayPass(java.time.LocalDate date) { validDate = date; }
    boolean isValid(java.time.LocalDate date) { return validDate.equals(date); }
}
class EBike { double fee(PricingRule rule, long minutes, LocalTime time) { return rule.fee(minutes,time); } }
class DeliveryVan { double fee(PricingRule rule, long minutes, LocalTime time) { return rule.fee(minutes,time); } }
public class DesignChallengeDemo {
    public static void main(String[] args) {
        LocalTime tenAM = LocalTime.of(10,0);
        System.out.println("E-bike flat fee Rs " + new EBike().fee(new FlatRule(15), 180, tenAM));
        System.out.println("Delivery van fee Rs " + new DeliveryVan().fee(new DeliveryVanRule(30), 120, tenAM));
        OneDayPass pass = new OneDayPass(java.time.LocalDate.now());
        System.out.println("Visitor one-day pass valid today: " + pass.isValid(java.time.LocalDate.now()));
    }
}