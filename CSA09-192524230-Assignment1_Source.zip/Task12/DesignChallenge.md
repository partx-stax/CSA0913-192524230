# Task 12 – Re-evaluate and Adapt the Design

## A. Impact analysis
The new categories are e-bikes and delivery vans; e-bikes have a flat parking fee, delivery vans pay twice the car rate between 9 AM and 5 PM, visitors can buy a one-day pass, and the facility has five floors with unequal slot counts. Vehicle subclasses, pricing strategy, pass validation and floor configuration are affected. A jagged array is necessary because floor capacities differ; a rectangular array would waste cells or impose an incorrect common capacity.

## B. Evaluation of original design
The abstract Vehicle and Chargeable interface remain useful. Adding e-bike and delivery-van subclasses is possible, but placing all pricing rules inside subclass overrides would spread time-window logic across classes. Existing ticket and slot classes can remain unchanged. Pricing should be moved into a `PricingRule` strategy so categories and time rules can be extended independently.

## C. Adaptation
Retain the core object model, modify fee calculation to delegate to PricingRule, add `EBike`, `DeliveryVan`, and `OneDayPass`, and configure five jagged floors (for example 40, 45, 50, 55, 60 slots). The one-day pass is valid for the calendar date purchased and grants a visitor the configured pass benefit; the sample treats it as free parking for that date. Delivery van surcharge applies when entry time is within [09:00, 17:00); outside that window it uses the normal car rate.

## D. Evidence-based defence
The adaptation adds two vehicle classes, a pricing abstraction and a visitor pass type; the ticket/slot classes and allocation algorithm remain unchanged. A further vehicle category can be added by supplying its pricing strategy without modifying the allocation code. The trade-off is a small additional policy object/reference and more explicit configuration, in exchange for reduced coupling and easier testing. The Java implementation is in `Task12/DesignChallengeDemo.java`; expected checks: e-bike fee is flat Rs.15; delivery van at 10:00 charges double the car rate; visitor with a valid one-day pass pays Rs.0.
