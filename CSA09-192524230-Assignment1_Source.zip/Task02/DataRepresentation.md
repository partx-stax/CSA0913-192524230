# Task 2 – Choose the Data Representation

| Field | Java type | Reason |
|---|---|---|
| Floor and slot index | `int` | Non-fractional index |
| Registration number | `String` | Alphanumeric identifier, not arithmetic |
| Ticket number | `long` | Large monotonically increasing identifier |
| Entry/exit time | `LocalDateTime` | Date and time with safe date arithmetic |
| Duration | `long` minutes | Avoids overflow for long stays |
| Fee/rate | `double` in the supplied exercise; `BigDecimal` preferred for production | Currency should ideally use decimal arithmetic |
| Occupancy | `Vehicle` reference or `null` | `null` means free |
| Charging units | `double` | Supports fractional kWh |

Use a jagged `String[][]`/`ParkingSlot[][]`: outer index is floor and each inner array has that floor's actual capacity. It supports different slot counts per floor and uses O(total slots) storage. A rectangular array wastes positions when capacities differ.

For billing, convert minutes to billable hours using integer ceiling: `(minutes + 59) / 60` for non-negative minutes. Integer division `130 / 60` gives 2, but charging each started hour requires 3. Do not cast after division: `(double)(130 / 60)` remains 2.0. Instead use `Math.ceil(minutes / 60.0)` or integer ceiling arithmetic. The completed code uses integer arithmetic.

Input can be read with `Scanner` for an interactive console program; command-line arguments are suitable for automated tests.

## Alternative representations
A single one-dimensional array needs a prefix-offset table when floor capacities differ; the simple formula `floor * slotsPerFloor + slot` only works for equal capacities. With equal capacities, locating an index is O(1); with variable capacities, offsets plus validation still give O(1) mapping. A jagged array uses `slots[floor][slot]` directly in O(1), with O(total slots + floors) references. `ArrayList<String[]>` has similar access complexity and can grow the number of floors dynamically, with small list-management overhead; each floor's inner array remains fixed unless replaced.
