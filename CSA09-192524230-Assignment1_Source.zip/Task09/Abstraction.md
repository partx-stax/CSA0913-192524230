# Task 9 – Introduce Abstraction

`Vehicle` is abstract because a generic vehicle has common identity and fee workflow but no universal hourly rate. `ratePerHour()` is abstract and subclasses implement it. `Chargeable` is an interface because charging is a capability that can be implemented by unrelated vehicle classes without forcing them into one inheritance branch. A class may implement multiple interfaces, e.g. `Chargeable`, `Insurable` and `PermitRequired`.

An interface default method is useful for a shared optional capability implementation; a static interface method can hold utility logic such as validating energy units. The abstract class can contain constructors, instance fields and implemented methods.

## Alternative: reverse the abstractions
If Vehicle became an interface, it could not provide ordinary per-instance fields or constructors; common registration state would need composition or repeated implementation. If Chargeable became an abstract class, Java's single class inheritance could prevent a class already extending another base class from also extending it. Method-call time remains O(1) in either design; per-object state depends on where registration/charging fields are stored. The original abstract-class-plus-interface combination expresses shared state plus independent capability cleanly.
