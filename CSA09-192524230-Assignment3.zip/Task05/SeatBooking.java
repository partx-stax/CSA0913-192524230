import java.util.concurrent.atomic.AtomicBoolean;
public class SeatBooking{
 private final AtomicBoolean[] seats; private int bookingsMade;
 SeatBooking(int n){seats=new AtomicBoolean[n];for(int i=0;i<n;i++)seats[i]=new AtomicBoolean(false);}
 public boolean book(int seat){
  if(seat<0||seat>=seats.length)throw new IllegalArgumentException();
  if(seats[seat].compareAndSet(false,true)){synchronized(this){bookingsMade++;}return true;}return false;
 }
 public static void main(String[] args)throws InterruptedException{
  SeatBooking screen=new SeatBooking(10); Thread[] users=new Thread[100];
  for(int i=0;i<100;i++){final int seat=i%10;users[i]=new Thread(()->screen.book(seat));users[i].start();}
  for(Thread t:users)t.join();System.out.println("Seats sold: "+screen.bookingsMade);
 }
}
