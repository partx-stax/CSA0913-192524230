import java.nio.file.*;import java.io.*;import java.util.*;import java.util.concurrent.*;
public class FaultTolerantProcessor{
 public static void main(String[] args)throws Exception{
  List<Path> files=List.of(Path.of("input/a.txt"),Path.of("input/b.txt"),Path.of("input/missing.txt"));
  ExecutorService pool=Executors.newFixedThreadPool(4);
  try{
   List<Future<String>> futures=new ArrayList<>();
   for(Path p:files)futures.add(pool.submit(()->{
    try{return p.getFileName()+": "+Files.readString(p).length()+" chars";}
    catch(IOException e){return p.getFileName()+": ERROR "+e.getClass().getSimpleName();}
   }));
   for(Future<String> f:futures)System.out.println(f.get());
  }finally{pool.shutdown();pool.awaitTermination(5,TimeUnit.SECONDS);}
 }
}
