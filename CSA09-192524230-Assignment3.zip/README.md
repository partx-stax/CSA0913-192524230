# CSA09-192524230-Assignment3
Parthiban M | 192524230 | AI & DS | Faculty: Dr. K. Pavithra
Java 17+. Repository: CSA09-192524230-Assignment3.
Compile individual programs using `javac -d out TaskXX/*.java` and run the named main class. Add screenshots and your own pool-size measurements. Q7 is group-based: complete the contribution record with your actual partner before submission.
