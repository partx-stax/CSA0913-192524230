# Assignment 3 – CO3: Exception Handling and Multithreading

Name: Parthiban M | Register No.: 192524230 | Department: AI & DS | Faculty: Dr. K. Pavithra

**Group-assignment note:** The PDF describes Q7 and parts of Q6 as joint work and asks for a Student A/Student B contribution record. The source/report here is an individual working draft. Confirm the partner's name and actual contribution before completing the joint-contribution table; do not claim another student's work.

## Q1 – ATM exception hierarchy
Use specific exceptions (`InvalidPinException`, `InsufficientFundsException`, `DailyLimitException`) rather than catching `Exception` for every failure. Catch the most specific type first, present a safe user message, log diagnostic details without recording PINs, and use `finally` for cleanup. Checked exceptions suit recoverable business conditions callers must handle; unchecked exceptions suit programming/invariant failures.

## Q2 – User-defined exceptions and propagation
Define domain exceptions with meaningful messages and preserve the original cause using `super(message, cause)`. Validate at the service boundary; let lower layers throw and higher layers translate to UI-safe messages. Avoid swallowing exceptions or printing stack traces as a substitute for handling.

## Q3 – try-with-resources and debugging
Use try-with-resources for streams, readers, JDBC connections and statements. Resources close even when an exception occurs; close failures are suppressed behind the primary exception. Catch only where recovery or translation is possible. Include contextual identifiers in logs, but never passwords or sensitive tokens.

## Q4 – Thread creation and life cycle
A Thread moves through NEW, RUNNABLE, BLOCKED, WAITING/TIMED_WAITING and TERMINATED. Prefer Runnable/Callable tasks submitted to an ExecutorService over manually creating many threads. `start()` schedules concurrent execution; calling `run()` directly is an ordinary method call on the current thread.

## Q5 – Race conditions and synchronization
A check-then-act booking must be atomic. Synchronize the critical section or use AtomicBoolean.compareAndSet for each seat. The supplied demo starts 100 contenders for 10 seats and guarantees exactly 10 successful bookings.

## Q6 – Deadlock and producer-consumer
Deadlock requires mutual exclusion, hold-and-wait, no pre-emption and circular wait. Enforce a global lock order to remove circular wait. For the bounded token counter, call wait() inside a while loop and synchronized method; notifyAll() after changing state. `wait()` releases the monitor; `sleep()` does not.

## Q7 – Concurrent fault-tolerant processor
Use a fixed-size ExecutorService, Callable per file, Future results, and a thread-safe result collector. Each task catches and records its own file error so one corrupt/missing file does not cancel the full batch. Shut down the executor in finally and await termination. One thread per file creates excessive stack/memory overhead; parallel streams offer less explicit failure isolation and pool control. For 10,000 files, use bounded concurrency and tune pool size from repeatable measurements.

## Complexity and evidence
For s seats, an array of AtomicBoolean uses O(s) space and compareAndSet is O(1) per attempt (contention can cause retries). A synchronized booking also uses O(s) seat storage and serializes the short critical section. A bounded queue of capacity 5 uses O(1) storage; put/take are O(1). A fixed thread pool uses O(p) worker threads for pool size p, rather than O(number of files).

## Group contribution record
Complete only after agreeing with the actual partner:
| Question | Student A primary | Student B primary | Joint |
|---|---|---|---|
| Q1–Q5 | Individual preparation; confirm | Confirm | Review |
| Q6 | Confirm producer/consumer or deadlock role | Confirm other role | Test |
| Q7 | Confirm design role | Confirm implementation role | Evaluate |
