import java.util.concurrent.*;
public class ThreadLifecycleDemo{
 public static void main(String[] args)throws Exception{
  ExecutorService pool=Executors.newFixedThreadPool(2);
  try{Future<Integer> f=pool.submit(()->{Thread.sleep(50);return 42;});System.out.println(f.get());}
  finally{pool.shutdown();pool.awaitTermination(2,TimeUnit.SECONDS);}
 }
}
