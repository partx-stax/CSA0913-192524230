CREATE TABLE bus_pass(
 pass_id VARCHAR(20) PRIMARY KEY,
 student_reg_no VARCHAR(20) NOT NULL,
 student_name VARCHAR(100) NOT NULL,
 route_no INT NOT NULL,
 boarding_stop VARCHAR(100) NOT NULL,
 valid_until DATE NOT NULL,
 amount_paise BIGINT NOT NULL
);
