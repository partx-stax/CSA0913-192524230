import java.sql.*;import java.util.*;
public class BatchInsert{
 static final String SQL="INSERT INTO bus_pass(pass_id,student_reg_no,student_name,route_no,boarding_stop,valid_until,amount_paise) VALUES(?,?,?,?,?,?,?)";
 public static void load(Connection c,int n)throws SQLException{
  boolean old=c.getAutoCommit();c.setAutoCommit(false);
  try(PreparedStatement p=c.prepareStatement(SQL)){
   for(int i=1;i<=n;i++){
    p.setString(1,"P"+i);p.setString(2,"1925"+String.format("%05d",i));
    p.setString(3,"Student"+i);p.setInt(4,(i%20)+1);p.setString(5,"Stop"+(i%30));
    p.setDate(6,java.sql.Date.valueOf("2027-03-31"));p.setLong(7,450000);
    p.addBatch();if(i%1000==0)p.executeBatch();
   }
   p.executeBatch();c.commit();
  }catch(SQLException e){c.rollback();throw e;}
  finally{c.setAutoCommit(old);}
 }
 public static void main(String[] args)throws Exception{
  String url=System.getenv("DB_URL"),user=System.getenv("DB_USER"),pwd=System.getenv("DB_PASSWORD");
  try(Connection c=DriverManager.getConnection(url,user,pwd)){
   for(int n:new int[]{1000,10000,100000}){long t=System.nanoTime();load(c,n);System.out.println(n+" rows: "+((System.nanoTime()-t)/1_000_000)+" ms");}
  }
 }
}
