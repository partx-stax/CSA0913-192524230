import java.io.*;import java.nio.file.*;import java.util.*;
public class IoBenchmark{
 static long byteRead(Path p)throws IOException{long n=0;try(InputStream in=Files.newInputStream(p)){while(in.read()!=-1)n++;}return n;}
 static long bufferedRead(Path p)throws IOException{long n=0;try(BufferedInputStream in=new BufferedInputStream(Files.newInputStream(p),8192)){byte[] b=new byte[8192];int k;while((k=in.read(b))!=-1)n+=k;}return n;}
 public static void main(String[] args)throws Exception{
  try(BufferedWriter w=Files.newBufferedWriter(Path.of("io-benchmark.csv"))){
   w.write("bytes,byte_read_ns,buffered_ns\n");
   for(int mb:new int[]{1,10,50}){
    Path p=Files.createTempFile("attendance",".log");
    try(OutputStream out=Files.newOutputStream(p)){byte[] block=new byte[8192];Arrays.fill(block,(byte)'x');for(int i=0;i<mb*128;i++)out.write(block);}
    byteRead(p);bufferedRead(p);long t=System.nanoTime();long a=byteRead(p);long x=System.nanoTime()-t;
    t=System.nanoTime();long c=bufferedRead(p);long y=System.nanoTime()-t;
    w.write(a+","+x+","+y+"\n");Files.delete(p);
   }
  }
  System.out.println("Wrote io-benchmark.csv; use measured values from this machine.");
 }
}
