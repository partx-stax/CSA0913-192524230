# Assignment 5 – CO5: Data Persistence Engineering

Name: Parthiban M | Register No.: 192524230 | Department: AI & DS | Faculty: Dr. K. Pavithra

## A1 – Design a file format
Text record: `passId|regNo|escapedName|route|boardingStop|validUntil|amount`. Escape backslash and pipe in text fields (or use a CSV library with quoted fields); include a schema/version header. Binary DataOutputStream layout: UTF passId, UTF regNo, UTF name, int route, UTF stop, long epochDay, long amountInPaise. DataOutputStream writes fields in declared order; length-prefixed UTF strings avoid fixed-width padding. Add: BufferedWriter append; find/list: BufferedReader sequential scan. A damaged line is rejected and logged with line number; missing file is created for add and reported as empty/not-found for read. For crash-safe updates, write a temporary file, flush/close, then atomically move into place; append-only logs can use checksums and recovery of the last complete record. RandomAccessFile fixed records permit O(1) seek by known record index, but ID lookup remains O(n) without an index; fixed-size padding wastes space.

## A2 – Buffering
A 50 MiB byte-at-a-time scan invokes approximately 52,428,800 Java read calls; each call has method/stream overhead and may cause frequent native reads if unbuffered. BufferedInputStream refills a block (commonly 8 KiB), reducing underlying reads to roughly fileSize/bufferSize, about 6,400 refills for 50 MiB, while Java still examines each byte. Buffering helps sequential I/O, not when data is already memory-resident or when each read requires an immediate response. Files.readAllLines is O(file size) time and O(file size) memory; buffered streaming is O(file size) time and O(buffer size) auxiliary memory.

## A3 – DAO pattern
Repeated steps: obtain connection, prepare SQL, bind values, execute, map ResultSet, close resources. Table-specific differences are SQL, key type and row mapper. `Dao<T,K>` defines insert/findById/findAll/update/delete; StudentDao implements it. Student fields map to student_id (primary key), name, email, department. Central DAO reduces schema-change locations; per-operation asymptotic time/space is unchanged.

## A4 – Serialization
Mark the live JDBC Connection `transient`; never serialize a password in plaintext—prefer not persisting it at all, or store a salted password hash in the authentication store. The object graph reachable from Hostel is traversed; non-transient serializable Room/Resident objects are included. Adding a field with stable serialVersionUID allows old streams to load with the new field defaulted (null/0); incompatible class changes can still fail. JSON/CSV is more portable and schema-readable; explicit versioning/migration is required.

## A5 – Transaction and injection
Disable auto-commit, debit source and credit destination, validate both row counts, commit only when both succeed; on any SQLException rollback. SQL string concatenation can be bypassed with crafted input such as `' OR '1'='1`; PreparedStatement binds data as values, not SQL syntax. PreparedStatement is the correct defence; escaping/regex filtering is brittle.

## B1 – File store and buffered line counter
`PassStore.find` reads lines with BufferedReader, skips malformed rows and returns matching fields. A missing ID returns null. Damaged lines do not stop scanning because each line is independently validated. The benchmark program creates 1, 10 and 50 MiB files and records buffered/unbuffered time to CSV; run it locally to produce actual results. Do not invent timing values.

## B2 – Adversarial input
Unsafe login can be bypassed with a crafted quote expression; PreparedStatement rejects it when no matching credential exists. Test malformed rows: wrong field count, non-numeric route/amount and empty line. The parser skips/reports invalid records and continues; input validation must occur before persistence.

## B3 – Statement, PreparedStatement and batch
Use a bus_pass table with primary key pass_id. Compare Statement, PreparedStatement and PreparedStatement batch inserts at 10, 1,000, 10,000 and 100,000 records. Use the same schema/data and measure elapsed time after warm-up. In a transaction, disable auto-commit, execute batch and commit; on forced failure rollback. Auto-commit may preserve rows inserted before the failure. Batch is generally suitable for nightly bulk import; PreparedStatement single-row insert is suitable at the counter.

## B4 – Final engineering decision
Choose a buffered, validated text import for simple interchange and JDBC PreparedStatement for database writes. Use transactions for multi-row consistency and batch execution for bulk loads. A production design should add indexes, duplicate policy, idempotent import keys, structured logging, backup/recovery and secrets management. Benchmark on the target DB/network before choosing batch size.
