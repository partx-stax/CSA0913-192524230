import java.sql.*;
public class SqlInjectionDemo{
 public static void main(String[] args)throws Exception{
  String url=System.getenv("DB_URL"),user=System.getenv("DB_USER"),pwd=System.getenv("DB_PASSWORD");
  if(url==null)throw new IllegalStateException("Set DB_URL, DB_USER and DB_PASSWORD for your local test database");
  try(Connection c=DriverManager.getConnection(url,user,pwd)){
   String id="' OR '1'='1";String password="anything";
   String unsafe="SELECT * FROM test_users WHERE id='"+id+"' AND pwd='"+password+"'";
   try(Statement st=c.createStatement();ResultSet rs=st.executeQuery(unsafe)){System.out.println("Unsafe accepted? "+rs.next());}
   try(PreparedStatement ps=c.prepareStatement("SELECT * FROM test_users WHERE id=? AND pwd=?")){
    ps.setString(1,id);ps.setString(2,password);try(ResultSet rs=ps.executeQuery()){System.out.println("Prepared accepted? "+rs.next());}
   }
  }
 }
}
