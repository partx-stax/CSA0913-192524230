# CSA09-192524230-Assignment5
Parthiban M | 192524230 | AI & DS | Faculty: Dr. K. Pavithra
Java 17+. Repository: CSA09-192524230-Assignment5.
File store: `javac TaskB1/PassStore.java` then `java -cp TaskB1 PassStore`. Benchmark: `javac TaskB1/IoBenchmark.java` then run. JDBC examples require MySQL Connector/J and local database credentials supplied via environment variables; never commit secrets. Run all experiments locally and retain raw CSV outputs/screenshots.
