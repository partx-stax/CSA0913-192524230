import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.*;
public class Converter extends JFrame{
 private final JTextField amount=new JTextField(10);
 private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"});
 private final JLabel result=new JLabel(" ");
 private static double rate(String c){return c.equals("USD")?0.012:0.011;}
 public Converter(){
  super("Currency Converter");setLayout(new FlowLayout());
  JButton convertButton=new JButton("Convert");
  add(new JLabel("INR"));add(amount);add(target);add(convertButton);add(result);
  ActionListener convert=e->convert();
  convertButton.addActionListener(convert);amount.addActionListener(convert);
  setDefaultCloseOperation(EXIT_ON_CLOSE);pack();setLocationRelativeTo(null);
 }
 private void convert(){
  try{
   double value=Double.parseDouble(amount.getText().trim());
   if(!Double.isFinite(value)||value<0)throw new NumberFormatException();
   result.setText(new DecimalFormat("0.00").format(value*rate((String)target.getSelectedItem())));
  }catch(NumberFormatException ex){result.setText("Invalid amount");}
 }
 public static void main(String[] args){SwingUtilities.invokeLater(()->new Converter().setVisible(true));}
}
