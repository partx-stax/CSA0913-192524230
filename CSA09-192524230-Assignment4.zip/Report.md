# Assignment 4 – CO4: Event-Driven GUI Design

Name: Parthiban M | Register No.: 192524230 | Department: AI & DS | Faculty: Dr. K. Pavithra

## Task 1 – GUI design review
Deficiencies: UI code mixes payment, validation and JDBC; action command uses `==` rather than equals; parse errors are not handled; SQL concatenation permits injection; database work and `sleep()` block the Event Dispatch Thread; receipt button has no distinct behaviour; connection/statement are not closed; user receives no progress/failure feedback; checked exceptions are ignored; window lifecycle is incomplete. Redesign with FeeWindow → FeeService → FeeDao. The window validates presentation-level emptiness, FeeService enforces business rules, DAO uses PreparedStatement and try-with-resources. Run slow work in SwingWorker and update UI in done().

## Task 2 – Requirement to event-driven design
Identify actors, controls, events, state and validation rules before coding. Use action listeners for button/menu actions, document/input listeners only when live validation is required, and a service layer for business logic. Events should trigger a short handler that delegates work rather than embedding the whole workflow.

## Task 3 – Layout design
Use BorderLayout for the main frame; GridBagLayout for aligned labels and fields; JPanel with FlowLayout for action buttons; JTable inside JScrollPane for tabular records. Menus should provide File/Export/Exit and Help/About. Dialogs should report validation errors and confirmation. Keep a sketch and map each component to its event.

## Task 4 – Event-handling forensics
Listeners are registered on event sources; the event object identifies source and command. Use `equals` for String comparison. Anonymous inner classes are useful for one-off handlers; named listeners are preferable when reused or independently testable. Adapter classes reduce boilerplate for listener interfaces with many methods.

## Task 5 – Four event-handling styles
The provided `Converter` demonstrates one lambda listener shared by Convert and Enter. Equivalent styles are a named ActionListener class, anonymous inner class, lambda, and method reference (`this::convert`). Method references are concise when signatures match. A shared Action object is reusable across button/menu/keyboard triggers.

## Task 6 – Campus event registration application
Actors: student and committee member. Screens: registration form and registration table/filter/export. Rules: required fields, valid email/register number, unique (student,event) pair, database errors shown safely. Architecture: RegistrationFrame (Swing UI), RegistrationService (validation/use cases), RegistrationDao (JDBC). Use SwingWorker for paginated database reads so the EDT remains responsive. Add a UNIQUE constraint on (student_id,event_id) to enforce duplicates at database level. Query pages using LIMIT/OFFSET and sort by stable primary key.

## Alternative and complexity
Loading all N=100,000 rows uses O(N) memory and may freeze the EDT during query/model construction. Page size P uses O(P) displayed-row memory and allows responsive incremental loading; database still performs indexed page retrieval. OFFSET can become slower at high offsets; keyset pagination by primary key is preferable for deep scrolling. The provided code is a runnable Swing converter; JDBC integration requires a configured local MySQL schema/driver.
