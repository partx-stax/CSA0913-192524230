import java.util.regex.Pattern;
public class FeeService{
 private static final Pattern REG=Pattern.compile("[A-Za-z0-9]{6,15}");
 public double validateAndCalculate(String regNo,String amount){
  if(regNo==null||!REG.matcher(regNo).matches())throw new IllegalArgumentException("Invalid registration number");
  double a;try{a=Double.parseDouble(amount);}catch(Exception e){throw new IllegalArgumentException("Invalid amount",e);}
  if(!Double.isFinite(a)||a<=0)throw new IllegalArgumentException("Amount must be positive");
  return a;
 }
}
