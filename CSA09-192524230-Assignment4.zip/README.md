# CSA09-192524230-Assignment4
Parthiban M | 192524230 | AI & DS | Faculty: Dr. K. Pavithra
Java 17+, Swing. Repository: CSA09-192524230-Assignment4.
Run `javac Task05/Converter.java` then `java -cp Task05 Converter`. GUI execution requires a desktop session. Add screenshots for valid and invalid input and complete the database challenge using your configured MySQL credentials; do not commit passwords.
