CREATE TABLE event_registration(
 registration_id BIGINT PRIMARY KEY AUTO_INCREMENT,
 student_id VARCHAR(20) NOT NULL,
 event_id BIGINT NOT NULL,
 student_name VARCHAR(100) NOT NULL,
 registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_student_event(student_id,event_id)
);
